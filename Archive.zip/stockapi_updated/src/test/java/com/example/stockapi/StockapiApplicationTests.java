package com.example.stockapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StockapiApplicationTests {

	@Test
	void contextLoads() {
	}

}
