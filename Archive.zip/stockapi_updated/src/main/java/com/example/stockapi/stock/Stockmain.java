package com.example.stockapi.stock;

public class Stockmain {

    public static void main(String[] args) {
       // Stock apple = new Stock("apple", "AAPC", 125, "11/6/2000", 13);
       // Stock microsoft = new Stock("MIc", "mc", 12, "11/6/2020", 12);
     
    }
}
