package com.example.capitalgains;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CapitalgainsApplication {

    public static void main(String[] args) {
        SpringApplication.run(CapitalgainsApplication.class, args);
    }

}
